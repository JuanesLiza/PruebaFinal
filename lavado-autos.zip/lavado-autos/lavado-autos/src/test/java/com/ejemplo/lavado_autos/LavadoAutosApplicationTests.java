package com.ejemplo.lavado_autos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LavadoAutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
