package com.ejemplo.lavado_autos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LavadoAutosApplication {

	public static void main(String[] args) {
		SpringApplication.run(LavadoAutosApplication.class, args);
	}
}