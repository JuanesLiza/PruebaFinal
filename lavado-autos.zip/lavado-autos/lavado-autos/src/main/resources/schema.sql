CREATE TABLE vehiculo (
                          id BIGINT AUTO_INCREMENT PRIMARY KEY,
                          marca VARCHAR(255),
                          placa VARCHAR(255),
                          servicio VARCHAR(255),
                          precio DOUBLE
);